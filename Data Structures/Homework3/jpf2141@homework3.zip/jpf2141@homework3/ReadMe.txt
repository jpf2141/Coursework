Programming 1: 

This program takes the file to be indexed as a command line argument. It requires compiliation of the WordListTester.java file, the MyLinkedList.java file, 
the UnderflowException.java file, and the AvlTree.java file, and needs the file to be indexed. The file supplied is called palindromes.txt. The program 
indexes the words in this file and prints the words and their respective line numbers to the console. 

Programming 2: 

This program takes 3 command line arguments. The first argument is the big dictionary, attached to the submission and called words.txt . 
The second command line argument is the personal dictionary, attached to the submission and called personalDict.txt . The third command
line argument is the name of the file to be spell checked, attached to the submission and called palindromes.txt . This program requires 
the compiliation of the SpellCheckTester.java file and the DictHashTable.java files. It spell-checks the palindromes.txt file, 
attached to the submission and called words.txt . 